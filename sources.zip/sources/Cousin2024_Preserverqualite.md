---
tags:
  - source/report
  - zotero
doi: 
itemKey: D4SVTF9W
---
>[!metadata]+
> Préserver la qualité des sols : vers un référentiel d'indicateurs. Résumé du rapport scientifique de l'étude
> [[Cousin, Isabelle]], [[Desrousseaux, Maylis]], [[Leenhardt, Sophie]], 
> [[INRAE]] (2024)
> [[soil quality]], [[Soil quality indicator]], 
> [Online link](https://hal.inrae.fr/hal-04798240), [Zotero Item](zotero://select/library/items/D4SVTF9W), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/NP587WEF/Cousin2024_Preserverqualite.pdf), 

# Notes %% begin notes %%
Shorter version of [[Cousin2025_Preserverqualite]]




%% end notes %%




%% Import Date: 2025-05-26T13:45:42.214+02:00 %%
