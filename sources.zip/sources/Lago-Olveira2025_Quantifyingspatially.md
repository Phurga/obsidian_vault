---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.ecoser.2024.101686
itemKey: SRE9YMKT
---
>[!metadata]+
> Quantifying spatially explicit LCA midpoint characterization factors to assess the impact of specific farming practices on ecosystem services
> [[Lago-Olveira, Sara]], [[Moreira, Maria Teresa]], [[González-García, Sara]], 
> [[ecosystem service]] (2025)
> 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S2212041624000937), [Zotero Item](zotero://select/library/items/SRE9YMKT), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/GDLBG5PX/Lago-Olveira2025_Quantifyingspatiallya.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.513+02:00 %%
