---
tags:
  - source/journalArticle
  - zotero
doi: 10.1007/s13280-021-01507-z
itemKey: H5PB7KR5
---
>[!metadata]+
> Biodiversity and ecosystem functioning in soil: The dark side of nature and the bright side of life: This article belongs to Ambio’s 50th Anniversary Collection. Theme: Agricultural land use
> [[Brussaard, Lijbert]], 
> [[Ambio]] (2021)
> 
> [Online link](https://link.springer.com/10.1007/s13280-021-01507-z), [Zotero Item](zotero://select/library/items/H5PB7KR5), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/9KVNK65M/Brussaard2021_Biodiversityecosystem.pdf), 

# Notes %% begin notes %%
[[biodiversity]]
[[ecosystem]]
[[soil function]]
[[soil]]
[[land use]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.609+02:00 %%
