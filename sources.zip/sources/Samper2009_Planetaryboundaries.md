---
tags:
  - source/journalArticle
  - zotero
doi: 10.1038/climate.2009.99
itemKey: KEW9ZP7S
---
>[!metadata]+
> Planetary boundaries: Rethinking biodiversity
> [[Samper, Cristián]], 
> [[Nature Climate Change]] (2009)
> [[biodiversity]], [[planetary boundaries]], 
> [Online link](https://www.nature.com/articles/climate.2009.99), [Zotero Item](zotero://select/library/items/KEW9ZP7S), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/36MYFTMN/Samper2009_Planetaryboundaries.pdf), 

# Notes %% begin notes %%
[[planetary boundaries]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:45.599+02:00 %%
