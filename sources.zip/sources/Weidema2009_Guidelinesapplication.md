---
tags:
  - source/report
  - zotero
doi: 
itemKey: INATCXQR
---
>[!metadata]+
> Guidelines for application of deepened and broadened LCA
> [[Weidema, Bo]], [[Heijungs, Reinout]], [[Ekvall, Tomas]], 
> [[ENEA, The Italian National Agency on new Technologies, Energy and the Environment]] (2009)
> [[consequential LCA]], 
> [Online link](https://lca-net.com/files/calcas_report_d18.pdf), [Zotero Item](zotero://select/library/items/INATCXQR), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/NT8JS7MD/_calcas_report_d18.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:46.759+02:00 %%
