---
tags:
  - source/report
  - zotero
doi: 
itemKey: PABZZBIE
---
>[!metadata]+
> Product User Manual 2.0
> [[WorldCover]], 
> [[WorldCover]] (2022)
> 
> [Online link](https://esa-worldcover.s3.eu-central-1.amazonaws.com/v200/2021/docs/WorldCover_PUM_V2.0.pdf), [Zotero Item](zotero://select/library/items/PABZZBIE), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/LTG738JD/_WorldCover_PUM_V20.pdf), 

# Notes %% begin notes %%
![[WorldCover2022_ProductUser_land_use_classification.png]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:46.881+02:00 %%
