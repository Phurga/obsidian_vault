---
tags:
  - source/report
  - zotero
  - source/book
doi: 
itemKey: M37I8FZP
---
>[!metadata]+
> Sustaining life on earth: how the Convention on biological diversity promotes nature and human well-being
> [[CBD]], 
> [[Convention on Biological Diversity]] (2000)
> [[important]], 
> [Online link](), [Zotero Item](zotero://select/library/items/M37I8FZP), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/EBVVWQV9/SecretariatoftheConventiononBiologicalDiversity2000_Sustaininglife.pdf), 

# Notes %% begin notes %%

> A major cause of this erosion is that individuals, communities and nations take the resource for granted. There is an assumption, based on thousands of years of development, that living resources and biological diversity are limitless. Despite isolated instances of where communities, even civilizations, have ignored this responsibility and suffered dramatically as a result, for most of us the idea that we might be reaching the limits of its endurance is beyond our experience and comprehension.

^77a682

%% end notes %%




%% Import Date: 2025-05-26T13:45:41.856+02:00 %%
