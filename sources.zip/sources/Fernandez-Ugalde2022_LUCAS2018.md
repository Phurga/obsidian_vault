---
tags:
  - source/report
  - zotero
doi: 
itemKey: S4RL7WB3
---
>[!metadata]+
> LUCAS 2018 soil module: presentation of dataset and results.
> [[Fernandez-Ugalde, Oihane]], [[Scarpa, S.]], [[Orgiazzi, Alberto]], [[Panagos, Panos]], [[van Liedekerke, M.]], [[Marechal, A.]], [[Jones, Arwyn]], 
> [[Publications Office of the European Union]] (2022)
> [[biodiversity]], [[soil]], [[LUCAS]], [[EU JRC]], [[ESDAC]], 
> [Online link](https://data.europa.eu/doi/10.2760/215013), [Zotero Item](zotero://select/library/items/S4RL7WB3), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/Q62H4G9E/EuropeanCommission.JointResearchCentre.2022_LUCAS2018.pdf), 

# Notes %% begin notes %%
%% end notes %%




%% Import Date: 2025-05-26T13:45:43.056+02:00 %%
