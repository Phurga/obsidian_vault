---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: HT5YEXXW
---
>[!metadata]+
> Indicators repository
> [[UNEP]], 
> [[Indicators for the Kunming – Montreal Global Biodiversity Framework]] (2025)
> [[Indicator]], [[convention on biological diversity]], [[Global biodiversity framework]], [[GBF]], [[CBD]], 
> [Online link](https://www.gbf-indicators.org/), [Zotero Item](zotero://select/library/items/HT5YEXXW), 

>[!abstract]-
>The indicators on this website aim to inform the process to develop the monitoring framework for the Kunming – Montreal Global Biodiversity Framework.

# Notes %% begin notes %%
Indicators for the [[Kunming-Montreal Global Biodiversity Framework]], linked to targets.
[[Kunming-Montreal Global Biodiversity Framework]]
![[UNEP2025_Indicatorsrepository_ecosystem_redlist.png]]

[[Kunming-Montreal Global Biodiversity Framework]]
![[UNEP2025_Indicatorsrepository_genetic_diversity.png]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:46.383+02:00 %%
