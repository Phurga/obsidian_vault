---
tags:
  - source/report
  - zotero
doi: 
itemKey: H5BB5DMH
---
>[!metadata]+
> LANCA: Land use indicator value calculation in life cycle assessment
> [[Beck, Tabea]], [[Bos, Ulrike]], [[Wittstock, Bastian]], [[Baitz, Martin]], [[Fischer, Matthias]], [[Sedlbauer, Klaus]], 
> [[Fraunhofer Verlag]] (2010)
> [[LANCA]], 
> [Online link](), [Zotero Item](zotero://select/library/items/H5BB5DMH), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/2SGT4L2S/LANCA.pdf), 

# Notes %% begin notes %%
Outdated and superseded with [[Bos2016_LANCACharacterization]].
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.177+02:00 %%
