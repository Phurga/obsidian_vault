---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: 5EX4BV5F
---
>[!metadata]+
> GIS REVALIM – Focus Biodiversité
> [[Cornelus, Melissa]], [[Asselin, Anne-Claire]], [[Rimbaud, Audrey]], 
> [[GIS REVALIM]] (2023)
> [[ADEME]], [[Agribalyse]], [[INRAE]], [[GIS REVALIM]], [[REVALIM]], 
> [Online link](https://www.dailymotion.com/video/x9bzv3y), [Zotero Item](zotero://select/library/items/5EX4BV5F), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:42.149+02:00 %%
