---
tags:
  - source/book
  - zotero
doi: 
itemKey: N6J2XQP4
---
>[!metadata]+
> Status of the world's soil resources: main report
> [[FAO and ITPS]], 
> [[FAP and ITPS]] (2015)
> [[important]], 
> [Online link](), [Zotero Item](zotero://select/library/items/N6J2XQP4), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/55828VWJ/2015_Statusworlds.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:43.000+02:00 %%
