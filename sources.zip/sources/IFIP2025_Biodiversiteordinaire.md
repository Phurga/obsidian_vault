---
tags:
  - source/report
  - zotero
doi: 
itemKey: V7EIK5NJ
---
>[!metadata]+
> Biodiversité ordinaire et agrosystèmes
> [[IFIP, ]], 
> [[IFIP]] (2025)
> [[biodiversity]], [[Agroecology]], 
> [Online link](), [Zotero Item](zotero://select/library/items/V7EIK5NJ), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/ADCEPQET/_plaquette_biodiversite_2025.pdf), 

# Notes %% begin notes %%
[[biodiversity]]
[[life cycle assessment]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:44.025+02:00 %%
