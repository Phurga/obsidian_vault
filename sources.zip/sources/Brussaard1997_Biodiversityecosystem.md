---
tags:
  - source/journalArticle
  - zotero
doi: 
itemKey: G7JXXSQL
---
>[!metadata]+
> Biodiversity and ecosystem functioning in soil
> [[Brussaard, Lijbert]], 
> [[Ambio]] (1997)
> [[important]], 
> [Online link](), [Zotero Item](zotero://select/library/items/G7JXXSQL), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/ZEEGXUPC/010012848.pdf), 

# Notes %% begin notes %%
[[Brussaard2021_Biodiversityecosystem]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.592+02:00 %%
