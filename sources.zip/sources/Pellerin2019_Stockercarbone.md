---
tags:
  - source/report
  - zotero
doi: 
itemKey: BFBLQA85
---
>[!metadata]+
> Stocker du carbone dans les sols français, Quel potentiel au regard de l’objectif 4 pour 1000 et à quel coût ? Synthèse du rapport d'étude
> [[Pellerin, Sylvain]], [[Bamière, Laure]], [[Réchauchère, Olivier]], 
> [[INRAE]] (2019)
> 
> [Online link](https://www.inrae.fr/sites/default/files/pdf/4pM-Synth%C3%A8se-Novembre2020.pdf), [Zotero Item](zotero://select/library/items/BFBLQA85), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/NEZM63NP/_4pMSyntheseNovembre2020.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:45.300+02:00 %%
