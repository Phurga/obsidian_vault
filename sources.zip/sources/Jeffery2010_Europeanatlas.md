---
tags:
  - source/report
  - zotero
  - source/book
doi: 
itemKey: 5UDKWQIW
---
>[!metadata]+
> European atlas of soil biodiversity.
> [[Jeffery, Simon]], [[Gardi, Ciro]], [[Jones, Arwyn]], [[Montanarella, Luca]], [[Marmo, Luca]], [[Miko, Ladislav]], [[Pérès, Guénola]], [[Römbke, Jörg]], [[van der Putten, Wim H.]], 
> [[Publications Office of the European Union]] (2010)
> [[EU JRC]], 
> [Online link](https://data.europa.eu/doi/10.2788/94222), [Zotero Item](zotero://select/library/items/5UDKWQIW), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/6NZ9QBHT/EuropeanCommission.JointResearchCentre.InstituteforEnvironmentandSustainability.2010_Europeanatlas.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.232+02:00 %%

>[!metadata]+
> European atlas of soil biodiversity.
> [[EU JRC]], 
> [[Publications Office of the European Union]] (2010)
> 
> [Online link](https://data.europa.eu/doi/10.2788/94222), [Zotero Item](zotero://select/library/items/5UDKWQIW), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/6NZ9QBHT/EuropeanCommission.JointResearchCentre.InstituteforEnvironmentandSustainability.2010_Europeanatlas.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-04-30T11:27:53.712+02:00 %%
