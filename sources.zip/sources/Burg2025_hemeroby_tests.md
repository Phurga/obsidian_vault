---
tags:
  - production/calculation
---
[file](file:\\\C:\Users\aburg\Documents\calculations\lindner_fehrenbach_cf_comparison.xlsx)
[[Lindner2019_ValuingBiodiversity]]
[[converting hemeroby classes to cardinal characterization factors]]

![[Burg2025_hemeroby_tests_transform_agri_forest.png]]