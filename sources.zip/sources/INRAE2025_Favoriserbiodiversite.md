---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: EN4E8L2W
---
>[!metadata]+
> Favoriser la biodiversité et renforcer les réseaux de services écosystémiques
> [[INRAE]], 
> [[BIOSEFAIR]] (2025)
> [[biodiversity]], [[ecosystem service]], 
> [Online link](https://biosefair.hub.inrae.fr/), [Zotero Item](zotero://select/library/items/EN4E8L2W), 

>[!abstract]-
>BIOSEFAIR

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.052+02:00 %%
