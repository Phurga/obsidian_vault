---
tags:
  - source/journalArticle
  - zotero
doi: 10.1021/es101444k
itemKey: 3NB4SR5Z
---
>[!metadata]+
> Toward Meaningful End Points of Biodiversity in Life Cycle Assessment
> [[Curran, Michael]], [[de Baan, Laura]], [[De Schryver, An M.]], [[Van Zelm, Rosalie]], [[Hellweg, Stefanie]], [[Koellner, Thomas]], [[Sonnemann, Guido]], [[Huijbregts, Mark A. J.]], 
> [[Environmental Science & Technology]] (2011)
> [[biodiversity]], [[important]], [[endpoint]], [[ecosystem quality]], [[life cycle impact assessment]], 
> [Online link](https://pubs.acs.org/doi/10.1021/es101444k), [Zotero Item](zotero://select/library/items/3NB4SR5Z), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/B43BECE2/Curran2011_MeaningfulEnd.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:42.413+02:00 %%
