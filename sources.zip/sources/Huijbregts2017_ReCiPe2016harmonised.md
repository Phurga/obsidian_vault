---
tags:
  - source/journalArticle
  - zotero
doi: 10.1007/s11367-016-1246-y
itemKey: D3K4SQJS
---
>[!metadata]+
> ReCiPe2016: a harmonised life cycle impact assessment method at midpoint and endpoint level
> [[Huijbregts, Mark A. J.]], [[Steinmann, Zoran J. N.]], [[Elshout, Pieter M. F.]], [[Stam, Gea]], [[Verones, Francesca]], [[Vieira, Marisa]], [[Zijp, Michiel]], [[Hollander, Anne]], [[Van Zelm, Rosalie]], 
> [[The International Journal of Life Cycle Assessment]] (2017)
> [[important]], [[recipe]], 
> [Online link](http://link.springer.com/10.1007/s11367-016-1246-y), [Zotero Item](zotero://select/library/items/D3K4SQJS), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/TBDYJ5BT/Huijbregts2017_ReCiPe2016harmonised.pdf), 

# Notes %% begin notes %%
[[recipe]] 
[[Goedkoop2013_ReCiPe2008]]
[[life cycle impact assessment]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:43.977+02:00 %%
