---
tags:
  - production/calculation
---
Excel file with calculation on species distribution per taxon

Topics:
[[taxonomy]] 
[[taxonomy]] 
[[species richness]] 

References:
[[Anthony2023_Enumeratingsoil]]
[[Zhang2013_Animalbiodiversity]]

Links:
[excel file](file:\\\C:\Users\aburg\Documents\calculations\species_count.xlsx)

Gallery:
![[Burg2025_speciesdistribution_taxa.png]]