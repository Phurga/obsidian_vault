---
tags:
  - source/statute
  - zotero
doi: 
itemKey: J6QMXTH9
---
>[!metadata]+
> 
> [[France Gouvernement]], 
>  (2021)
> [[climante change]], [[resilience]], 
> [Online link](), [Zotero Item](zotero://select/library/items/J6QMXTH9), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-06-02T09:58:40.195+02:00 %%
