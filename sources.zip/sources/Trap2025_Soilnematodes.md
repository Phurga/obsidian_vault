---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: Q8LTHF2H
---
>[!metadata]+
> Soil nematodes (Les nématodes du sol)
> [[Trap, Jean]], 
> [[formation ecologie des sols]] (2025)
> [[important]], [[soil]], [[nematode]], 
> [Online link](), [Zotero Item](zotero://select/library/items/Q8LTHF2H), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/RPN2GL59/_04_Nematodes_JTrap_FormationEcologieDuSol_2024.pdf), 

# Notes %% begin notes %%
Key concepts on [nematodes](app://obsidian.md/nematodes), their anatomy, diversity, functions.
%% end notes %%




%% Import Date: 2025-05-26T13:45:46.271+02:00 %%
