---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: DTFRVVW6
---
>[!metadata]+
> The IUCN Red List of Threatened Species
> [[IUCN]], 
> [[IUCN Red List of Threatened Species]] (2025)
> [[important]], 
> [Online link](https://www.iucnredlist.org/en), [Zotero Item](zotero://select/library/items/DTFRVVW6), 

>[!abstract]-
>Established in 1964, the IUCN Red List of Threatened Species has evolved to become the world’s most comprehensive information source on the global conservation status of animal, fungi and plant species.

# Notes %% begin notes %%
[[IUCN red ist of threatened species]]
![[IUCN2025_IUCNReda_species_coverage_time.png]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:44.171+02:00 %%
