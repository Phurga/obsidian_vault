---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: V4RH3GHG
---
>[!metadata]+
> Worldcover Homepage
> [[ESA]], 
> [[WorldCover]] (2025)
> [[land use]], [[land cover]], [[dataset]], 
> [Online link](https://esa-worldcover.org/en), [Zotero Item](zotero://select/library/items/V4RH3GHG), 

>[!abstract]-
>WorldCover provides the first global land cover products for 2020 and 2021 at 10 m resolution, developed and validated in near-real time based on Sentinel-1 and Sentinel-2 data.

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:42.905+02:00 %%
