---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: MBXU3FQY
---
>[!metadata]+
> Soil Biodiversity: Why Should We Care?
> [[Briones, Maria J.I.]], 
> [[GLOBAL SYMPOSIUM ON SOIL BIODIVERSITY]] (2021)
> 
> [Online link](https://www.fao.org/fileadmin/user_upload/GSP/GSOBI-21/DAY2/PS3/14-15/1_Briones_ID42.pdf), [Zotero Item](zotero://select/library/items/MBXU3FQY), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/SWJJ6GFQ/_presentaiton_soil_biodiversity.pdf), 

# Notes %% begin notes %%
[[soil biodiversity|soil biodiversity]]
#todo/read
[[IUCN]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.547+02:00 %%
