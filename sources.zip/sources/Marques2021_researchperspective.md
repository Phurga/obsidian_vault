---
tags:
  - source/journalArticle
  - zotero
doi: 10.1007/s11367-020-01846-1
itemKey: W2N8YRX4
---
>[!metadata]+
> A research perspective towards a more complete biodiversity footprint: a report from the World Biodiversity Forum
> [[Marques, Alexandra]], [[Robuchon, Marine]], [[Hellweg, Stefanie]], [[Newbold, Tim]], [[Beher, Jutta]], [[Bekker, Sebastian]], [[Essl, Franz]], [[Ehrlich, Daniele]], [[Hill, Samantha]], [[Jung, Martin]], [[Marquardt, Sandra]], [[Rosa, Francesca]], [[Rugani, Benedetto]], [[Suárez-Castro, Andrés F.]], [[Silva, André P.]], [[Williams, David R.]], [[Dubois, Grégoire]], [[Sala, Serenella]], 
> [[The International Journal of Life Cycle Assessment]] (2021)
> [[biodiversity]], [[unread]], 
> [Online link](https://doi.org/10.1007/s11367-020-01846-1), [Zotero Item](zotero://select/library/items/W2N8YRX4), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/FN4MWIM9/Marques2021_researchperspective.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.868+02:00 %%
