---
tags:
  - source/journalArticle
  - zotero
doi: 10.1021/acs.est.5b03683
itemKey: 7YB98DTN
---
>[!metadata]+
> Using the Reliability Theory for Assessing the Decision Confidence Probability for Comparative Life Cycle Assessments
> [[Wei, Wei]], [[Larrey-Lassalle, Pyrène]], [[Faure, Thierry]], [[Dumoulin, Nicolas]], [[Roux, Philippe]], [[Mathias, Jean-Denis]], 
> [[Environmental Science & Technology]] (2016)
> 
> [Online link](https://pubs.acs.org/doi/10.1021/acs.est.5b03683), [Zotero Item](zotero://select/library/items/7YB98DTN), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/8N474S9V/dumoulin-et-al-2016-using-the-reliability-theory-for-assessing-the-decision-confidence-probability-for-comparative-life.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:46.745+02:00 %%
