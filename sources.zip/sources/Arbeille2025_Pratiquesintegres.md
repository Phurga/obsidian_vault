---
tags:
  - source/journalArticle
  - zotero
doi: 10.17180/MENY-7E85
itemKey: VIVXM9EF
---
>[!metadata]+
> Pratiques intègres de publication scientifique à l’heure de la science ouverte. Note de recommandations.
> [[Arbeille, Sabine]], [[Denis Bourguet, ]], [[Regina Dashkina, ]], [[Philippe Delcros, ]], [[Erwin Dreyer, ]], [[Christian Duquennoi, ]], [[Valérie Gaudin, ]], [[Thomas Guillemaud, ]], [[Antoine Kremer, ]], [[Véronique Lesage, ]], [[Rafael Muñoz-Tamayo, ]], [[Isabelle Ortigues Marty, ]], [[Stéphanie Rennes, ]], [[Masoomeh Taghipoor, ]], [[Denis Tagu, ]], 
> [[]] (2025)
> [[epistemology]], [[meta]], 
> [Online link](https://hal.inrae.fr/hal-04964196), [Zotero Item](zotero://select/library/items/VIVXM9EF), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/JD24L5CS/Arbeille2025_Pratiquesintegres.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:40.987+02:00 %%
