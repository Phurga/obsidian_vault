---
tags:
  - source/report
  - zotero
doi: 
itemKey: UIHWQ8SM
---
>[!metadata]+
> Technologies To Maintain Biological Diversity
> [[OTA]], 
> [[Office of Technology Assessment]] (1987)
> 
> [Online link](), [Zotero Item](zotero://select/library/items/UIHWQ8SM), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/LVP2AAZ3/Food_TechnologiesMaintain.pdf), 

# Notes %% begin notes %%
[[biodiversity]] definition early
%% end notes %%




%% Import Date: 2025-05-26T13:45:45.259+02:00 %%
