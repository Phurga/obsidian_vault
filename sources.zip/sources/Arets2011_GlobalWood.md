---
tags:
  - source/report
  - zotero
doi: 
itemKey: SVWNUR4Y
---
>[!metadata]+
> Global Wood Production: Assessment of Industrial Round Wood Supply from Forest Management Systems in Different Global Regions
> [[Arets, Eric]], [[van der Meer, Peter]], [[Verwer, Caspar Carolus]], [[Hengeveld, Geerten]], [[Tolkamp, G. W.]], [[Nabuurs, G. J.]], [[van Oorschot, M.]], 
> [[Alterra]] (2011)
> 
> [Online link](), [Zotero Item](zotero://select/library/items/SVWNUR4Y), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/4ZUU89PT/Verwer_68PUBLICATIONS.pdf), 

# Notes %% begin notes %%
#data
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.006+02:00 %%
