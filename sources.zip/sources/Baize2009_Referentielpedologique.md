---
tags:
  - source/book
  - zotero
doi: 
itemKey: 24YFBJJ8
---
>[!metadata]+
> Référentiel pédologique 2008
> [[Baize, Denis]], [[Girard, Michel C.]], 
> [[Éditions Quæ]] (2009)
> [[soil]], [[pedology]], [[soil type]], [[AFES]], [[classification]], 
> [Online link](), [Zotero Item](zotero://select/library/items/24YFBJJ8), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/RTHZ76SP/Baize2009_Referentielpedologique.pdf), 

# Notes %% begin notes %%
[[Référentiel Pédologique Français]]
%% end notes %%




%% Import Date: 2025-06-02T11:04:37.651+02:00 %%
