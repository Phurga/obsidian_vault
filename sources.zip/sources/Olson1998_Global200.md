---
tags:
  - source/journalArticle
  - zotero
doi: 10.1046/j.1523-1739.1998.012003502.x
itemKey: RVT52BQE
---
>[!metadata]+
> The Global 200: A Representation Approach to Conserving the Earth’s Most Biologically Valuable Ecoregions
> [[Olson, David M.]], [[Dinerstein, Eric]], 
> [[Conservation Biology]] (1998)
> [[important]], 
> [Online link](https://onlinelibrary.wiley.com/doi/abs/10.1046/j.1523-1739.1998.012003502.x), [Zotero Item](zotero://select/library/items/RVT52BQE), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/SACPAE27/Olson1998_Global200a.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:45.165+02:00 %%
