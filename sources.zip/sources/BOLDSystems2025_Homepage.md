---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: A4WSZYYB
---
>[!metadata]+
> Homepage
> [[BOLD Systems]], 
> [[BOLD – The Barcode of Life Data Systems]] (2025)
> [[DNA]], [[DNA barcoding]], 
> [Online link](https://boldsystems.org/), [Zotero Item](zotero://select/library/items/A4WSZYYB), 

# Notes %% begin notes %%
linked to this webpage, to use for [[DNA metabarcoding]], there is a great taxonomic coverage and geographical coverage but i'm not sure about land use class coverage.
![[BOLDSystems2025_Homepage_BIN.png]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.305+02:00 %%
