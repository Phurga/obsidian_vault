---
tags:
  - source/journalArticle
  - zotero
doi: 
itemKey: J5F9VP7X
---
>[!metadata]+
> Biodiversity Evaluation Tools for European Forests
> [[Larsson, Tor-Björn]], [[Angelstam, Per]], [[Balent, Gérard]], [[Barbati, Anna]], [[Bijlsma, Rienk-Jan]], [[Boncina, Andrej]], [[Bradshaw, Richard]], [[Bücking, Winfried]], [[Ciancio, Orazio]], [[Corona, Piermaria]], [[Diaci, Jurij]], [[Dias, Susana]], [[Ellenberg, Herrmann]], [[Fernandes, Francisco Manuel]], [[Fernández-Gonzalez, Frederico]], [[Ferris, Richard]], [[Frank, Georg]], [[Møller, Peter Friis]], [[Giller, Paul]], [[Gustafsson, Lena]], [[Halbritter, Klaus]], [[Hall, Susannah]], [[Hansson, Lennart]], [[Innes, John]], [[Jactel..., Hervé]], 
> [[Ecological Bulletins]] (2001)
> 
> [Online link](http://www.jstor.org/stable/20113288), [Zotero Item](zotero://select/library/items/J5F9VP7X), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/ALQRZLMC/Larsson2001_BiodiversityEvaluation.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.547+02:00 %%
