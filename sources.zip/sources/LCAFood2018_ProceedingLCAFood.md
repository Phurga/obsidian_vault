---
tags:
  - source/conferencePaper
  - zotero
doi: 
itemKey: GWLAWHGJ
---
>[!metadata]+
> Proceeding LCAFood 2018
> [[LCA Food]], 
> [[11th International Conference on Life Cycle Assessment of Food 2018 (LCA Food)]] (2018)
> 
> [Online link](), [Zotero Item](zotero://select/library/items/GWLAWHGJ), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/8T5QG3XJ/Proceeding%20LCAFood%202018.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.559+02:00 %%
