---
tags:
  - source/report
  - zotero
doi: 
itemKey: XXR3KPDY
---
>[!metadata]+
> Rapport du conseil scientifique de l’affichage environnemental
> [[Soler, Louis-Georges]], [[Dubuisson-Quellier, Sophie]], [[Garcia-Launay, Florence]], [[Hélias, Arnaud]], [[Julia, Chantal]], [[Nabec, Juliane]], [[Pellerin, Sylvain]], [[Ruffieux, Bernard]], [[Trystram, Gilles]], [[van der Werf, Hayo M.G.]], 
> [[ADEME]] (2025)
> 
> [Online link](), [Zotero Item](zotero://select/library/items/XXR3KPDY), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/X6MC58A5/Soler_RAPPORTCONSEIL.pdf), 

# Notes %% begin notes %%
[[environmental labelling]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:46.056+02:00 %%
