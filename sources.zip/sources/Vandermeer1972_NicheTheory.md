---
tags:
  - source/journalArticle
  - zotero
doi: 10.1146/annurev.es.03.110172.000543
itemKey: YAJFTSJC
---
>[!metadata]+
> Niche Theory
> [[Vandermeer, John H.]], 
> [[Annual Review of Ecology, Evolution, and Systematics]] (1972)
> [[ecology]], [[niche theory]], [[ecological niche]], 
> [Online link](https://www.annualreviews.org/content/journals/10.1146/annurev.es.03.110172.000543), [Zotero Item](zotero://select/library/items/YAJFTSJC), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-27T15:39:25.284+02:00 %%
