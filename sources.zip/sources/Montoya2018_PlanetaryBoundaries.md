---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.tree.2017.10.004
itemKey: 3YQA2YGD
---
>[!metadata]+
> Planetary Boundaries for Biodiversity: Implausible Science, Pernicious Policies
> [[Montoya, José M.]], [[Donohue, Ian]], [[Pimm, Stuart L.]], 
> [[Trends in Ecology & Evolution]] (2018)
> [[biodiversity]], [[important]], [[planetary boundaries]], 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S016953471730263X), [Zotero Item](zotero://select/library/items/3YQA2YGD), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/3JVD29WE/Montoya2018_PlanetaryBoundaries.pdf), 

# Notes %% begin notes %%
#favourite 
%% end notes %%




%% Import Date: 2025-05-26T13:45:45.023+02:00 %%
