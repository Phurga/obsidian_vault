---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: JW9F3CAE
---
>[!metadata]+
> Towards considering functional diversity in impact assessment
> [[Scherer, Laura]], 
> [[87th LCA Discussion Forum]] (2024)
> [[biodiversity]], [[functional diversity]], [[LCA Discussion Forum]], [[life cycle impact assessment]], 
> [Online link](https://lca-forum.ch/fileadmin/generic_lib/Resources/Public/Downloads/DF87/3_Scherer_DF87_2024.pdf), [Zotero Item](zotero://select/library/items/JW9F3CAE), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/V6C9HWEA/Scherer_CONSIDERINGFUNCTIONAL.pdf), 

# Notes %% begin notes %%
See also [[Rosa2024_Landuseimpacts]]

%% end notes %%




%% Import Date: 2025-05-26T13:45:45.772+02:00 %%
