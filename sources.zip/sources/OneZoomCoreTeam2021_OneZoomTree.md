---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: VTJQPMBY
---
>[!metadata]+
> OneZoom Tree of Life Explorer Version 4.0
> [[OneZoom Core Team]], 
> [[OneZoom Tree of Life Explorer]] (2021)
> [[biodiversity]], [[Taxonomy]], 
> [Online link](https://www.onezoom.org/), [Zotero Item](zotero://select/library/items/VTJQPMBY), 

# Notes %% begin notes %%
**OneZoom** is a great website to see the phylogenetic classification. I used it to create a custom [[taxonomy|taxonomy]].

https://www.onezoom.org/life/@biota=93302?otthome=%40%3D770315#x637,y806,w0.8870

![[OneZoomCoreTeam2021_OneZoomTree_overview.png]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:45.188+02:00 %%
