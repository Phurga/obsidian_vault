---
tags:
  - source/journalArticle
  - zotero
doi: 10.1111/1365-2435.14720
itemKey: SAXJZRZQ
---
>[!metadata]+
> Linking effect traits of soil fauna to processes of organic matter transformation
> [[Bonfanti, Jonathan]], [[Potapov, Anton M.]], [[Angst, Gerrit]], [[Ganault, Pierre]], [[Briones, Maria J. I.]], [[Calderón-Sanou, Irene]], [[Chen, Ting-Wen]], [[Conti, Erminia]], [[Degrune, Florine]], [[Eisenhauer, Nico]], [[Ferlian, Olga]], [[Hackenberger, Davorka]], [[Hauer, Amelie]], [[Hedde, Mickael]], [[Hohberg, Karin]], [[Krogh, Paul Henning]], [[Mulder, Christian]], [[Perez-Roig, Camila]], [[Russell, David]], [[Shelef, Oren]], [[Zhou, Zheng]], [[Zuev, Andrey G.]], [[Berg, Matty P.]], 
> [[Functional Ecology]] (2025)
> 
> [Online link](https://besjournals.onlinelibrary.wiley.com/doi/10.1111/1365-2435.14720), [Zotero Item](zotero://select/library/items/SAXJZRZQ), 

>[!abstract]-
>Read the free Plain Language Summary for this article on the Journal blog.

# Notes %% begin notes %%
![[Bonfanti2025_Linkingeffect_traits_som_functions.jpg]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.344+02:00 %%
