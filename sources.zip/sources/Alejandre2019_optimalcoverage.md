---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.jclepro.2019.05.284
itemKey: JIH6T2NQ
---
>[!metadata]+
> Towards an optimal coverage of ecosystem services in LCA
> [[Alejandre, Elizabeth M.]], [[Van Bodegom, Peter M.]], [[Guinée, Jeroen B.]], 
> [[Journal of Cleaner Production]] (2019)
> 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S0959652619318207), [Zotero Item](zotero://select/library/items/JIH6T2NQ), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/TY5V8VU8/Alejandre2019_optimalcoverage.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:40.910+02:00 %%
