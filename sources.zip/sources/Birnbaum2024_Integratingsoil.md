---
tags:
  - source/journalArticle
  - zotero
doi: 10.1111/nph.19440
itemKey: IQX2E748
---
>[!metadata]+
> Integrating soil microbial communities into fundamental ecology, conservation, and restoration: examples from Australia
> [[Birnbaum, Christina]], [[Dearnaley, John]], [[Egidi, Eleonora]], [[Frew, Adam]], [[Hopkins, Anna]], [[Powell, Jeff]], [[Aguilar-Trigueros, Carlos]], [[Liddicoat, Craig]], [[Albornoz, Felipe]], [[Heuck, Meike K.]], [[Dadzie, Frederick A.]], [[Florence, Luke]], [[Singh, Pankaj]], [[Mansfield, Tomas]], [[Rajapaksha, Kumari]], [[Stewart, Jana]], [[Rallo, Paola]], [[Peddle, Shawn D.]], [[Chiarenza, Giancarlo]], 
> [[New Phytologist]] (2024)
> [[soil]], [[Australia]], [[conservation]], [[mycorrhizal fungi]], [[restoration]], [[soil microbes]], 
> [Online link](https://onlinelibrary.wiley.com/doi/abs/10.1111/nph.19440), [Zotero Item](zotero://select/library/items/IQX2E748), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/ET8QKD6S/Birnbaum2024_Integratingsoil.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:41.269+02:00 %%
