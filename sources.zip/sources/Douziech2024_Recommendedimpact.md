---
tags:
  - source/report
  - zotero
doi: 
itemKey: ZS5ZHULL
---
>[!metadata]+
> Recommended impact  assessment method within Swiss Agricultural Life Cycle  Assessment (SALCA): v2.01
> [[Douziech, Mélanie]], [[Bystricky, Maria]], [[Furrer, Cédric]], [[Gaillard, Gérard]], [[Lansche, Jens]], [[Roesch, Andreas]], [[Nemecek, Thomas]], 
> [[Agroscope]] (2024)
> 
> [Online link](https://ira.agroscope.ch/en-US/publication/56332), [Zotero Item](zotero://select/library/items/ZS5ZHULL), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:42.779+02:00 %%
