---
tags:
  - source/journalArticle
  - zotero
doi: 10.1128/jb.180.18.4765-4774.1998
itemKey: 8SGWGU4Q
---
>[!metadata]+
> Impact of Culture-Independent Studies on the Emerging Phylogenetic View of Bacterial Diversity
> [[Hugenholtz, Philip]], [[Goebel, Brett M.]], [[Pace, Norman R.]], 
> [[Journal of Bacteriology]] (1998)
> [[phylogenetic diversity]], [[bacteria]], 
> [Online link](https://journals.asm.org/doi/10.1128/jb.180.18.4765-4774.1998), [Zotero Item](zotero://select/library/items/8SGWGU4Q), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/CKE34EGU/Hugenholtz1998_ImpactCultureIndependent.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:43.948+02:00 %%
