---
tags:
  - source/journalArticle
  - zotero
doi: 10.1080/00031305.2019.1583913
itemKey: KR3VUIYZ
---
>[!metadata]+
> Moving to a World Beyond “p < 0.05”
> [[Wasserstein, Ronald L.]], [[, Schirm ,Allen L.]], [[and Lazar, Nicole A.]], 
> [[The American Statistician]] (2019)
> 
> [Online link](https://doi.org/10.1080/00031305.2019.1583913), [Zotero Item](zotero://select/library/items/KR3VUIYZ), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/UV9HM6HH/Wasserstein2019_MovingWorld.pdf), 

# Notes %% begin notes %%
[[statistics]]
[[scientific method]]

analysis and interpretation of results
> Don't use the term statistically significant

> Don't base findings and conclusions of your work based on p-values or metrics for statistical difference.

Part 7 for practical recommendations
%% end notes %%




%% Import Date: 2025-05-26T13:45:46.727+02:00 %%
