---
tags:
  - source/journalArticle
  - zotero
doi: 10.1111/ejss.13299
itemKey: 9XQBRLSN
---
>[!metadata]+
> LUCAS Soil Biodiversity and LUCAS Soil Pesticides, new tools for research and policy development
> [[Orgiazzi, Alberto]], [[Panagos, Panos]], [[Fernandez-Ugalde, Oihane]], [[Wojda, Piotr]], [[Labouyrie, Maëva]], [[Ballabio, Cristiano]], [[Franco, Antonio]], [[Pistocchi, Alberto]], [[Montanarella, Luca]], [[Jones, Arwyn]], 
> [[European Journal of Soil Science]] (2022)
> 
> [Online link](https://bsssjournals.onlinelibrary.wiley.com/doi/10.1111/ejss.13299), [Zotero Item](zotero://select/library/items/9XQBRLSN), 

>[!abstract]-
>The European Green Deal puts a healthy environment at the core of policy-making initiatives in the European Union (EU). Soil, due to its nature, is a central actor to be considered when developing a...

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:45.242+02:00 %%
