---
tags:
  - source/thesis
  - zotero
doi: 
itemKey: 4RNRHHZX
---
>[!metadata]+
> Quantitative representation of the effects of land-use processes on biodiversity in life cycle assessments
> [[Lindner, Jan Paul]], 
> PhD thesis, [[Fraunhofer-Institut für Bauphysik]] (2016)
> [[biodiversity]], 
> [Online link](https://www.bookshop.fraunhofer.de/buch/Quantitative-Darstellung-der-Wirkungen-landnutzender-Prozesse-auf-die-Biodiversit%C3%A4t-in-%C3%96kobilanzen/246142), [Zotero Item](zotero://select/library/items/4RNRHHZX), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/9HPEIW8K/Lindner2016_QuantitativeDarstellung.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:44.644+02:00 %%
