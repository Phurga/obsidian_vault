---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.cub.2019.08.007
itemKey: K25TRFHI
---
>[!metadata]+
> Challenges and Opportunities for Soil Biodiversity in the Anthropocene
> [[Geisen, Stefan]], [[Wall, Diana H.]], [[Van Der Putten, Wim H.]], 
> [[Current Biology]] (2019)
> [[biodiversity]], [[soil]], 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S0960982219310231), [Zotero Item](zotero://select/library/items/K25TRFHI), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/XPNLY2U2/Geisen2019_ChallengesOpportunities.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:43.321+02:00 %%
