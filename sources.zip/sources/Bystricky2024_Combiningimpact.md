---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: TDC6IEZS
---
>[!metadata]+
> Combining the impact on biodiversity of agricultural management practices at local scale with land use at global scale
> [[Bystricky, Maria]], [[Jeanneret, Philippe]], 
> [[87th LCA Discussion Forum]] (2024)
> [[biodiversity]], [[LCA Discussion Forum]], [[agricultural management practices]], [[agricultural practices]], [[SALCA]], [[life cycle impact assessment]], 
> [Online link](https://lca-forum.ch/fileadmin/generic_lib/Resources/Public/Downloads/DF87/5_LCA-DF_Bystricky_SALCA-BD.pdf), [Zotero Item](zotero://select/library/items/TDC6IEZS), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/XXC97KGN/Bystricky_Combiningimpact.pdf), 

# Notes %% begin notes %%
The method selected [[indicator species]] groups (ISGs) of signifi
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.705+02:00 %%
