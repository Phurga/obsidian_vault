---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.jclepro.2018.12.238
itemKey: C25ZMCKI
---
>[!metadata]+
> Soil quality index: Exploring options for a comprehensive assessment of land use impacts in LCA
> [[De Laurentiis, Valeria]], [[Secchi, Michela]], [[Bos, Ulrike]], [[Horn, Rafael]], [[Laurent, Alexis]], [[Sala, Serenella]], 
> [[Journal of Cleaner Production]] (2019)
> [[soil quality]], [[important]], [[LANCA]], [[soil]], [[unread]], 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S095965261833960X), [Zotero Item](zotero://select/library/items/C25ZMCKI), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/MJQJ4CHB/DeLaurentiis2019_Soilquality.pdf), 

# Notes %% begin notes %%
[[soil quality index]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:42.576+02:00 %%
