---
tags:
  - source/report
  - zotero
doi: 
itemKey: XWMECL7B
---
>[!metadata]+
> THE GLOBIO MODEL  A technical description of version 3.5
> [[PBL]], 
> [[PBL]] (2016)
> [[GLOBIO]], 
> [Online link](), [Zotero Item](zotero://select/library/items/XWMECL7B), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/UJDEGT7B/pbl_publication_2369.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:45.285+02:00 %%
