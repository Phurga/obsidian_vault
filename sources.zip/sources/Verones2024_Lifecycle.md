---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: B4ABTRCC
---
>[!metadata]+
> Life cycle assessment and biodiversity impacts - basics and updates
> [[Verones, Francesca]], 
> [[LCN Seminar series]] (2024)
> [[biodiversity]], [[life cycle impact assessment]], [[life cycle assessment]], 
> [Online link](https://www.youtube.com/watch?v=g-80BoRrId4), [Zotero Item](zotero://select/library/items/B4ABTRCC), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:46.548+02:00 %%
