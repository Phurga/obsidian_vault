---
tags:
  - source/journalArticle
  - zotero
doi: 10.1016/j.tree.2024.05.013
itemKey: IEZEUBP5
---
>[!metadata]+
> Trade-offs in soil microbial functions and soil health in agroecosystems
> [[Gao, Chenguang]], [[Bezemer, Thiemo Martijn]], [[De Vries, Franciska T.]], [[Van Bodegom, Peter M.]], 
> [[Trends in Ecology & Evolution]] (2024)
> [[soil]], 
> [Online link](https://linkinghub.elsevier.com/retrieve/pii/S0169534724001381), [Zotero Item](zotero://select/library/items/IEZEUBP5), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/WSGHEWZE/Gao2024_Tradeoffssoila.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:43.246+02:00 %%
