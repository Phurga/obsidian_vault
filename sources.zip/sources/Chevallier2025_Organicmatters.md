---
tags:
  - source/presentation
  - zotero
doi: 
itemKey: 47NTAR4E
---
>[!metadata]+
> Organic matters and ecosystem services (Matières organiques et services ecosystémiques)
> [[Chevallier, Tiphaine]], 
> [[formation ecologie des sols]] (2025)
> [[ecosystem service]], [[soil organic matter]], 
> [Online link](), [Zotero Item](zotero://select/library/items/47NTAR4E), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/29I5X8YV/_05_MO_TChevallier_FormationEcologieSol2025.pdf), 

# Notes %% begin notes %%

%% end notes %%




%% Import Date: 2025-05-26T13:45:42.085+02:00 %%
