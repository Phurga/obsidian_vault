---
tags:
  - source/report
  - zotero
doi: 
itemKey: R8T39RZF
---
>[!metadata]+
> Préserver la qualité des sols : vers un référentiel d’indicateurs. Rapport d’étude
> [[Cousin, Isabelle]], [[Desrousseaux, Maylis]], [[Angers, Denis]], [[Augusto, Laurent]], [[Ay, Jean-Sauveur]], [[Baysse-Lainé, Adrien]], [[Branchu, Philippe]], [[Brauman, Alain]], [[Chemidlin, Prévost-Bouré]], [[Compagnone, Claude]], [[Gros, Raphaël]], [[Hermon, Carole]], [[Keller, Catherine]], [[Laroche, Bertrand]], [[Meulemans, Germain]], [[Montagne, David]], [[Pérès, Guénola]], [[Saby, Nicolas]], [[Vaudour, Emmanuelle]], [[Villerd, Jean]], [[Violle, Cyrille]], [[Lelievre, Virginie]], [[de, Mareschal]], [[Brichler, Marie-Caroline]], [[Froger, Claire]], [[Itey, Julie]], [[Leenhardt, Sophie]], 
> [[INRAE]] (2025)
> 
> [Online link](https://hal.inrae.fr/hal-04934694), [Zotero Item](zotero://select/library/items/R8T39RZF), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/JJZ3ZIAN/Cousin_Preserverqualite.pdf), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/Q8PPJCHS/2025_05_26_IQS_ReunionDU-Dpt.pdf), 

# Notes %% begin notes %%
Longest version
%% end notes %%




%% Import Date: 2025-05-28T16:44:09.487+02:00 %%
