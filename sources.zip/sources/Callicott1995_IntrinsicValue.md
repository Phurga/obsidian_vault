---
tags:
  - source/journalArticle
  - zotero
doi: 
itemKey: 48NXSPUT
---
>[!metadata]+
> Intrinsic Value in Nature: A Metaethical Analysis
> [[Callicott, J. Baird]], 
> [[Electronic Journal of Analytic Philosophy]] (1995)
> 
> [Online link](), [Zotero Item](zotero://select/library/items/48NXSPUT), 

# Notes %% begin notes %%
[[intrinsic value of nature]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.772+02:00 %%
