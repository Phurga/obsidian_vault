---
tags:
  - source/webpage
  - zotero
doi: 
itemKey: CTBBE5SA
---
>[!metadata]+
> Interpreting counts and frequencies in OTU tables
> [[Edgar, Robert C.]], 
> [[drive5 - Robert C. Edgar Blog]] (2025)
> 
> [Online link](https://drive5.com/usearch/manual/otu_count_interpret.html), [Zotero Item](zotero://select/library/items/CTBBE5SA), 

# Notes %% begin notes %%
[[operational taxonomic unit|OTU]] 
[[DNA metabarcoding]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:42.797+02:00 %%
