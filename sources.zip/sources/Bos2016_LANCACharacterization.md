---
tags:
  - source/report
  - zotero
doi: 
itemKey: V5KUCD2V
---
>[!metadata]+
> LANCA® - Characterization Factors for Life Cycle Impact Assessment. Version 2.0.
> [[Bos, Ulrike]], [[Horn, Rafael]], [[Beck, Tabea]], [[Lindner, Jan Paul]], [[Fischer, Matthias]], 
> [[Fraunhofer Verlag]] (2016)
> [[important]], [[LANCA]], [[life cycle impact assessment]], 
> [Online link](https://publica.fraunhofer.de/handle/publica/297633), [Zotero Item](zotero://select/library/items/V5KUCD2V), [Local pdf](file://C:/Users/aburg/Documents/references/zotero/storage/ARN88ZZP/LANCA2.pdf), 

# Notes %% begin notes %% 
See [[LANCA]]
%% end notes %%




%% Import Date: 2025-05-26T13:45:41.480+02:00 %%
