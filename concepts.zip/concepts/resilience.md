---
tags:
  - concept/definition
aliases:
  - resilient
---
