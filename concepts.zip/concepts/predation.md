---
tags:
  - concept/definition
aliases:
  - prey
  - predator
---
**Predation** is a [[biological interaction]] consisting of a **predator** organism hunting and killing a **prey** organism to feed on.