---
tags:
  - concept/definition
---
[[chosing relevant indicators]]
[[statistics]]
