---
tags:
  - concept/definition
---
**Ontology**: a formal model of domain knowledge that describes concepts and their relationships using mathematical logic.