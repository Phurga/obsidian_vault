---
tags:
  - concept/definition
---
**Endemic richness** is 