---
tags:
  - concept/definition
aliases:
---
An **enzyme** is a protein that acts as a biological catalyst by accelerating chemical reactions. ([wikipedia](https://en.wikipedia.org/wiki/Enzyme))