---
tags:
  - concept/definition
aliases:
---
Cultural services are [[ecosystem service]].
They include:
- aesthetics
- recretation
- education