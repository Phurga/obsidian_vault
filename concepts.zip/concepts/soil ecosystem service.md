---
tags:
  - concept/definition
aliases:
  - soil services
---
**Soil ecosystem services** (or soil services) are [[ecosystem service]] provided through [[soil function|soil functionning]] to humans.

[[FAO2020_Stateknowledge]] recap:
![[FAO2020_Stateknowledge_services_biodiversity.png|400]]