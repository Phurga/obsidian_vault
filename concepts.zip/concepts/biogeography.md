---
tags:
  - concept/definition
---
**Biogeography** is the study of the geographic distribution of species.

> Biogeography is the study of the geographic distribution of species and, by extension, of the ecological (distribution and functioning of communities and ecosystems), taxonomic (richness and composition of faunal collections) and genetic (distribution and relationships between populations) dimensions of biodiversity. ^[https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/biogeography]

environmental gradients
[[island biogeography]]
[[species-area relationship]]