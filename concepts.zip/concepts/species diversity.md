---
tags:
  - concept/definition
aliases:
---
**Species diversity** is an indicator of [[ecological composition]] used to measure [[biodiversity]]. It is more complex indicator than [[species richness]], accounting also for [[species abudance]]. It it then more challenging to implement given that it requires more data.