---
tags:
  - concept/definition
---
A **stochastic** process is the result of random forces and is studied using statistics. Synonym: random. Opposite: deterministic.
