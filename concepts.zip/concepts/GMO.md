---
tags:
  - concept/definition
aliases:
  - genetically modified organisms
  - GMO
---
A **genetically modified organisms (GMO)** ...