---
tags:
  - concept/definition
aliases:
  - labile carbon
  - stable carbon
---


See:
[[Chevallier2025_Organicmatters]]
[[carbon transformation]]