---
tags:
  - concept/idea
---
Biodiversity is affected by a multitude of parameters ([[pressures on soils]])
The [[potential threats to biological functions]] defines 13 main pressures