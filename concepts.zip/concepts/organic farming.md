---
tags:
  - concept/definition
  - todo/draft
aliases:
  - organic product
---
**Organic farming** describes [[land management]] following a specific set of rules, mostly forbidding the use of [[chemical inputs]] such as [[mineral fertilizer]] or synthetic [[pesticides]].
# ideas
[[organic farming reduces impacts on biodiversity]]