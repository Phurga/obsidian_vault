---
tags:
  - concept/definition
---
Diversity of [[ecosystem]]s.

One element is the diversity of [[biome]]s, but also the integrity of [[ecoregion]] (biomes that can have different communities ie species).

Indicator: [[red list of ecosystems]]

#concept/idea how about a m2 based indicator weighted on the risk of converting a red list biome ? (not link with soils though)