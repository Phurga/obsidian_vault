---
tags:
  - concept/definition
aliases:
---
A good example of a cardinal scale is the numeric scale.
A cardinal scale supports the same properties as an [[ordinal scale]], and also supports addition and multiplication.
This is the typical scale we use in mathematics.