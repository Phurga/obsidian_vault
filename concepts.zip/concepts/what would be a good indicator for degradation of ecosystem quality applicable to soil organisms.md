---
tags:
  - concept/idea
---
species richness is the current consensus for macro organisms due to data availability ([[UNEP2016_GlobalGuidance]], [[Woods2018_Ecosystemquality]])

species richness 