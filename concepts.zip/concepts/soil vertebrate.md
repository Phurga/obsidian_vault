---
tags:
  - concept/definition
  - todo/draft
aliases:
  - vertebrates
  - soil megafauna
  - megafauna
---
**Soil vertebrates** constitute [[soil megafauna]]. #todo/notsure They are mostly [[rodents]] (moles, gophers). They interact with the [[soil]] as they dig into for [[biotope|habitat]] it or for foraging.

#todo/question how about reptiles and amphibious ?
#todo/question can grazing animals be considered as soil vertebrates since they interact with soil through manure ?
# Ecological functions
Fossorial species generally increase [[soil function]], creating soil heterogeneities. 
Tunnels and excavated portions of soil create depressions, favouring moisture (water infiltrations), warmer temperatures, and organic matter finding microbes.

[[FAO2020_Stateknowledge]] I found the paragraph 2.3.13 poorly written.