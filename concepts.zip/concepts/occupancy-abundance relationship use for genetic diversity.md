---
tags:
  - concept/idea
---
[[occupancy-abundance relationship]]
[[minimum population size to maintain evolutionary potential|proportion of populations within species with an effective population size over 500]]
