---
tags:
  - concept/definition
---
There are **three major realms** of life:
- terrestrial
- marine
- freshwater
These are the main physical realms, hosting the global biodiversity. 