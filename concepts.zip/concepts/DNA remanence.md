---
tags:
  - concept/definition
---


**[[DNA]] is remanent** in soils and in water. This means that DNA found in environmental samples can be attributed to living organisms but also to organisms that have died years ago.

DNA has been found to be remanent for cultivated plants for 8 years [[Foucher2020_Persistenceenvironmental]].