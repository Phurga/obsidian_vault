---
tags:
  - concept/definition
---
In the [[ORCHAMP]] database, there was particular caution related to when [[environmental DNA]] sampling was done: all in autumn.
This is important because we expect seasonal variability in microbial presence.

