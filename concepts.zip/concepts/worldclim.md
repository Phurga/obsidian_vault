---
tags:
  - concept/definition
  - data
---
https://www.worldclim.org/data/bioclim.html

**WorldClim** is a list of spatial bioclimatic information.