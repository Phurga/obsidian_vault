---
tags:
  - concept/idea
---
[[Edgar2025_Interpretingcounts]]
[[low correlation between OTU read abundance and species true abundance]]
[[Challenges in extending land use change impacts on biodiversity to soil organisms]]
[[Calderon-Sanou2022_betterunderstanding]] chapter 1
[[Orgiazzi2015_Soilbiodiversity]]