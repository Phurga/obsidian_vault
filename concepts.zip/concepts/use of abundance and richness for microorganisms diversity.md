---
tags:
  - concept/idea
---
## challenges
![[Calderon-Sanou2022_betterunderstanding#^b92ab3]]

There is no need for a [[species-area relationship]] for microorganisms since they are considered to be everywhere.