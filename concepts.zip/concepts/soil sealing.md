---
tags:
  - concept/definition
---
**Soil sealing** is the covering of soil with impervious materials such as cement or asphalt. It is associated to urban development and intensification.