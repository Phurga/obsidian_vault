---
tags:
  - concept/definition
---
![[Calderon-Sanou2022_betterunderstanding#^674194]]

This hypothesis is back up by the concept of competition-exclusion: a disturbance will clear a habitat from its biocenose and let space for competition, leading to immigrating species (regional species) to colonize the area.
Note that thus we are considering an increase in [[alpha diversity]], where the alpha diversity has potential for increases based on a regional pool of species ([[gamma diversity]]).
