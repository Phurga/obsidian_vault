---
tags:
  - concept/definition
aliases:
---
**Ecosystem engineers** is a functional group in the [[soil food web]], for [[earthworm]], [[ant]] as they have profound effect on the [[ecosystem]] (for soil ecosystems, on [[soil structure]]). Transforming the ecosytem creates a diversity of [[biotope|habitat]]s and it then a major driver of [[species richness]] and [[landscape heterogeneity]].

References:
[[FAO2020_Stateknowledge]]