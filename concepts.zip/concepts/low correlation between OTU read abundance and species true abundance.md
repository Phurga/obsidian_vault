---
tags:
  - concept/idea
---
https://drive5.com/usearch/manual/read_cell_correl.html refering to this study https://www.biorxiv.org/content/10.1101/124149v1

[[environmental DNA]]
[[operational taxonomic unit|OTU]]
[[DNA metabarcoding]]
[[species abudance]]
