---
tags:
  - concept/idea
aliases:
---
Interesting relationship between samples (similar to area) and species richness in [[Jabot2025_Usemassive]]
![[Jabot2025_Usemassive_sar_sample_soil.png|300]]

