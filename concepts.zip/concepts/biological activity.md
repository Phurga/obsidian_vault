---
tags:
  - concept/definition
aliases:
---
**Biological activity** refers to ? (respiration, reproduction, metabolism, primary production).
#todo 

Indicators for activity are:
- respiration rates (CO2 rate - but CO2 does not mean healthy, might mean stressed).