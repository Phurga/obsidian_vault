---
tags:
  - concept/definition
aliases:
---
**Eusocial** [[taxonomy]] (mainly [[insects]]) show the highest levels of social organization among animals. They are cooperative, have intergenerational communities with "adults" and a division of labor.