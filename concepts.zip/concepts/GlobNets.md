---
tags:
  - concept/definition
---
**GlobNets** is a research project aiming at collecting [[environmental DNA]] samples across the world, and especially in Norway and in the French Alps.

[link](https://umr-ecofog.cirad.fr/projets/globnets-global-biogeography-of-ecological-networks-in-forest-ecosystems)
