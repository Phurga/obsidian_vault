---
aliases:
  - ecological complexes
  - ecosystems
tags:
  - concept/definition
---
An **ecosystem** is a system formed by an interacting community of organisms ([[ecological composition|biocenosis]]) in an environment ([[biotope]]).

## spatial scales
[[biome]]
[[ecoregion]]
[[organism]]
[[soil]]
[[biosphere]]