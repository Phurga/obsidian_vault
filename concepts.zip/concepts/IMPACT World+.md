---
tags:
  - concept/definition
aliases:
---
[[life cycle impact assessment]] method, global approach, wide midpoint cover.

webinar:
https://www.impactworldplus.org/impact-world-webinar/