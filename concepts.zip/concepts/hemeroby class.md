---
tags:
  - concept/definition
aliases:
  - hemeroby classification
  - hemeroby classes
---
**Hemeroby classification** is a way of classifying [[land use]] types based on their distance to nature. These class can be sorted: this is an [[ordinal scale]].
[[Fehrenbach2015_Hemerobyimpact]] suggests a 7 class hemeroby classification.
![[Fehrenbach2015_Hemerobyimpact_hemeroby_classes.png]]