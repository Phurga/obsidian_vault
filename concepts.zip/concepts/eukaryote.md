---
tags:
  - concept/definition
aliases:
  - eukaryotes
---
**Eukaryotes** are [[organism|organisms]] whose cells have a nucleus. They are usually multi-celled, but can be single celled (some [[fungus]] like yeasts, some [[algae]], [[protozoae]]).
The eukaryotes taxon contains all [[plants]], [[fungus]] and [[animal]]. 