---
tags:
  - concept/definition
---
The **phenotype** of an [[organism]] is its set of observable [[species trait|traits]].