---
tags:
  - concept/definition
---
**Phosphorus** is an element, symbol P, number 15, atomic mass 31.
Critical in life since it is used to synthetise [[DNA]] and other important organisms compounds.

Common forms are [[phosphate]], [[ATP]], [[DNA]], [[RNA]], phospholipids (used in cell membrane).