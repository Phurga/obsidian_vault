---
tags:
  - concept/definition
  - todo/draft
---
A **barcode index number** can be associated to an [[operational taxonomic unit]], and usually associated to a specie (but a specie requires some characterisation).

![[BOLDSystems2025_Homepage_BIN.png|]]