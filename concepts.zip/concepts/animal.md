---
tags:
  - concept/definition
aliases:
  - animal
---
[[birds]]
[[mammals]]
[[insects]] [[soil arthropod]]
[[worms]] [[earthworm]] [[nematode]] 
[[reptiles]]
[[amphibious]]
