---
tags:
  - concept/definition
aliases:
---
**Nature conservation** is a form of [[environmental ethics]] based on the respect and valuation of nature for what it is ([[intrinsic value of nature]]) and what is provides humans. It can be multidimensional.

[[Depraz2013_Notionproteger]]
![[Depraz2013_Notionproteger_protection_nature.png|600]]

![[Godet2017_Notiondebat#^4498dc]]
