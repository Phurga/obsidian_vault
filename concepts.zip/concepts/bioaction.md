---
tags:
  - concept/definition
aliases:
---

#todo
[[biostimulation]]
[[biocontrol]]
 [[bioremediation]]