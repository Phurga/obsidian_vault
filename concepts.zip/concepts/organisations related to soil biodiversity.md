---
tags:
  - concept/index
---
## Soil
[[Intergovernmental Technical Panel on Soil]] (ITPS)
[[Food and Agriculture Organisation]] (FAO)
[[Global Soil Partnership]] (GSP)
[[European Soil Data Center]] (ESDAC)
[[European Union Soil Observatory]] (EUSO)
- [[LUCAS]]
[[Association Francaise pour l'étude des sols]] (AFES)
[[International Union for Soil Sciences]] (IUSS)

## Soil Biodiversity
[[Global Soil Biodiversity Initiative]] (GSBI)
[[International Network on Soil Biodiversity]] (NETSOB)
Global Soil Biodiversity Observatory (GLOSOB) (plan of NETSOB)
[[Réseau de Mesures de la Qualité des Sols]]
## Biodiversity (non soil)
[[Global Biodiversity Information Network]] (GBIF)
