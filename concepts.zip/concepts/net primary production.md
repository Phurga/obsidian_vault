---
tags:
  - concept/definition
aliases:
---
#todo 
Mentioned I think in [[Verones2017_LCIAframework]] and in [[UNEP2019_GlobalGuidance]].