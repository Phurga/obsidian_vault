---
tags:
  - concept/definition
---
[[acidification]]
[[eutrophication]]
[[ecotoxicity]]

[[UNEP2019_GlobalGuidance]]
Suggested methods :
Terrestrial exotoxicity (PAF)> Rosenbaum 2011 + Owsianiak 2013 for HM, to PAF
Terrestrial acidification (SO2eq>PDF)> Rot 2012, Azevedo 2013