---
tags:
  - concept/idea
---
[[occupancy-abundance relationship]]
[[species-area relationship]]

[[species diversity]] indicators