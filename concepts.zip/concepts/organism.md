---
tags:
  - concept/definition
aliases:
  - organisms
---
Individual unit for a living being.

See also:
[[biodiversity]]
