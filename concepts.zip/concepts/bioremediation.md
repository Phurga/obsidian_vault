---
tags:
  - concept/definition
aliases:
  - depollution
---
Bioremediation is the depollution of the environment through biological activity.
Example, [[FAO2020_Stateknowledge]]
> Soil bacteria and fungi can reduce petroleum hydrocarbons after a spill by up to 85 percent.