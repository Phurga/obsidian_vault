---
tags:
  - concept/definition
---
The **Land Cover Classification System (LCCS)** is a land cover classification scheme developped by the [[Food and Agriculture Organisation]] and [[UN]].