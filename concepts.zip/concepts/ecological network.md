---
tags:
  - concept/definition
---
An **ecological network** is a representation of [[biological interaction]]s in a [[ecological composition|biological community]]. So in a way it is related to [[ecological structure]].

There is ongoing study of ecological networks and scholar are looking for indicators to *quantify* interactions, for instance it is done in representaiton of [[food web]]s through energy indicators. 