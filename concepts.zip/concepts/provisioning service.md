---
tags:
  - concept/definition
  - todo/draft
aliases:
---
Ecosystem provisioning services are [[ecosystem service]] related to primary production for human consumption.
They include:
- increased productivity for food, fiber, fuel, water, medical products
- increase food quality
- genetic pool