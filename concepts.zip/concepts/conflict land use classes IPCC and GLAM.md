---
tags:
  - concept/idea
---
[[DeLaurentiis2024_Soilorganic]]

Land use elementary flows needs curating, conflicts between [[GLAM]] and [[IPCC]] classes.
Results are sensitive to subnational [[regionalisation]]

[[land use#classification]]