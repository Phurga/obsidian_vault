---
tags:
  - concept/definition
---
[[VeronesFrancesca2024_Lifecycle]]
[[invasive alien species#Modelling in LCA]]