---
tags:
  - concept/definition
aliases:
---
**Invertebrates** are organisms with no spine. They include notably : [[soil arthropod|arthropods]], [[mollusks]], annelids ([[earthworm]]), [[echinoderms]], [[flatworms]], [[cnidarians]], and [[sponges]].

**Invertebrates** is not a [[taxonomy|phylogenetic group]] but a paraphyletic group (defined by opposition to one taxon).