---
tags:
  - concept/definition
---
**Salinization** occurs when #todo 
Salinization is an important agronomic problem since it can prevent from plants to grow and leads to [[desertification]].