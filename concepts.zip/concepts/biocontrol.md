---
tags:
  - concept/definition
aliases:
---
Examples:
- [[bacillus thuringiensis]] (bacteria), used as an insecticide
- especially in maize : maize was genetically engineered to integrate [[Bt gene]] in maize tissue.
- most used insecticide in [[organic farming]]
- warning: negative effects can occur (resistance, reduced biodiversity)