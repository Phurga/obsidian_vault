---
tags:
  - concept/definition
---
The **Elton niche** applies to [[heterotroph]]ic organisms, and relates to requirements regarding the [[ecological composition|ecological community]]. There is a need for other organisms providing it food sources (direct for e.g. predation, indirect for e.g. detritivores) and need for limiting abundance of predators/enemies.

Related:
[[ecological network]]
