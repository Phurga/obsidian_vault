---
tags:
  - concept/definition
---
See [[16S rRNA]].
This one if for [[eukaryote]].