---
tags:
  - concept/definition
aliases:
  - 16S
---
**16s ribosomal RNA (rRNA)** is a [[marker]] (group of genes) specific to [[prokaryote]]s, used to replicate [[bacteria]]l DNA during [[DNA metabarcoding]].

The equivalent for eukaryotes are [[18s rRNA]] genes.

Mentionned as a mature indicator for bacterial diversity analysis in [[Cousin2025_Preserverqualite]].