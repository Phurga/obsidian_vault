---
tags:
  - concept/definition
---
[[EuropeanCommission2025_ProposalDirective]]