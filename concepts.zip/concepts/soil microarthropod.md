---
tags:
  - concept/definition
aliases:
  - microarthropods
---
**Soil microarthropods** are [[soil arthropod|arthropods]] in the size range 0.1mm to 2mm.
They are primarly represented with:
- [[mite]],
- [[springtail]].

See also: [[soil macroarthropod]]

References:
[[FAO2020_Stateknowledge]]