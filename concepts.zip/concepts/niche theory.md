---
tags:
  - concept/definition
---
**Niche theory** is a theory in ecology aiming at explaing the distribution of species based on environmental conditions and available resources. This theory led to the concept of [[biotope|ecological niche]].

Originally developped by [[Grinnell, Joseph]] in 1924 and further developped across the following decades.

## references
[[Vandermeer1972_NicheTheory]]