---
tags:
  - concept/definition
aliases:
  - macrofauna
---
In [[soil biodiversity|soil biodiversity]], the soil **macrofauna** consists of:
- [[earthworm]]
-  [[soil macroarthropod]], such as [[ant]], [[termite]] and more.