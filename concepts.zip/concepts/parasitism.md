---
tags:
  - concept/definition
aliases:
  - parasit
  - parasits
---
