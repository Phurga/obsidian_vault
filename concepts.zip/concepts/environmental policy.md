---
tags:
  - concept/definition
---
law
- soil
	- [[EU soil monitoring law]]
	- [[FranceGouvernement2021_LOIndeg|loi climat et résilience]]
- land beyond soil ("foncier", landscape)
- air and water policy
conventions
- [[convention on biological diversity]]
	- [[Kunming-Montreal Global Biodiversity Framework]]
- [[Global Soil Partnership]]
- [[UNEP]]
[[environmental ethics]]
- [[nature conservation]]
- resource exploitation and environmental liberalism
- nature as vector of identity
tools for environmental policies
- [[monitoring the advancement of conservation policies is the main goal of biodiversity LCIA]]
- [[Cousin2025_Preserverqualite]] on how to select indicators for policy making