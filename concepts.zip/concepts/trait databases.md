---
tags:
  - concept/definition
---
FungalTraits (fungi)
FUNGuild (fungi)
FAPROTAX (bacteria)
TRY (plants)
NEMAGuild (nematodes)
trophic grouping for fauna ([[Soil Food Web Ontology]])
list: https://www.brc.ac.uk/theme/species-traits-links-data-and-resources
## handles
[[species trait|functional trait]]
[[functional diversity]]
[[operational taxonomic unit|MOTU]]
[[DNA metabarcoding]]
