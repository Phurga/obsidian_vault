---
tags:
  - concept/definition
aliases:
---
Related to the [[mean species abundance|species abundance]]. For a given [[biotope|habitat]], the abundance of a species will increase or decrease near the **edge** of said habitat.