---
tags:
  - concept/definition
aliases:
  - dormant
---
#todo 