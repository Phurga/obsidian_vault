---
tags:
  - concept/definition
aliases:
---
[[biological nitrogen fixation]]