---
tags:
  - concept/definition
---
**La fresque du sol** is a workshop designed by the [[Association Francaise pour l'étude des sols]] (see [[AFES2022_fresquesol]])  broadcast knowledge about [[soil]]s to the public.

![[AFES2022_fresquesol_FresqueSolsAmandine.png]]

It is founded on the framework used in Calvaruso et al., 2020
![[AFES2022_fresquesol_FrameworkSoilsCalvaruso2020.png]]
Soil properties and processes> Soil functions > Ecosystem services > Human benefits
\+ human pressures on soil properties challenging the cascade

[[GIS Sol]]
[[les-sols-dominants-de-france-metropolitaine_hautedef.pdf]]
