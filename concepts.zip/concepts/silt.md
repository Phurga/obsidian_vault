---
tags:
  - concept/definition
aliases:
---
**Silts** are intermediate mineral compounds in the size range (2micrometer<size<50micrometer). Silts have no [[electronic reactivity]] but do not allow for important [[drainage]] of soil. They are 'neutral' compounds. 

The formation of silts is not well known. Silts are easily transported by water (and rivers) and are found in good quantities in fluviosoils.