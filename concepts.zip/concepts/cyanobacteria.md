---
tags:
  - concept/definition
aliases:
---
**Cyanobacteria** are [[bacteria]] that can perform [[photosynthesis]].
They are cyan (blue-green) hence their name.
They are not [[algae]].