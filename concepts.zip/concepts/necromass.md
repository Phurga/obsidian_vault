---
tags:
  - concept/definition
aliases:
---
**Necromass** is former [[biomass]]. It can be decaying compounds, eaten by [[detritivore]]s or fresh dispersed tissues such as bacteria killed by viruses through lysis.

The necromass usually a nutrient hotpost, and also an imporant medium term source of [[soil organic matter|soil organic carbon]]. This means viruses favour medium term carbon pools. Former theorists used to think that soil organic matter was complex plant tissues, but this medium term SOM is more necromass trapped in clay pockets.