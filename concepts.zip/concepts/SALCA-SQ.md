---
tags:
  - concept/definition
---
**SALCA-SQ** (for [[soil quality]]) is an LCIA method defined in [[Oberholzer2012_novelmethod]] focusing on #todo/draft 