---
tags:
  - concept/definition
---
**SoilGrids** is a database for spatial soil information publish by the [[ISRIC]]

https://soilgrids.org/