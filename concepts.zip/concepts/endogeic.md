---
tags:
  - concept/definition
aliases:
  - endogeics
---
An **endogeic** [[taxonomy]] lives under groud. Hypo-endogeic lives deep and epi-endogeic lives in the top soil. Applies to [[earthworm]].