---
tags:
  - concept/definition
aliases:
---
**Heterotroph** organisms get their energy and carbon from other organisms. They are opposite to [[autotroph]] who get their energy from abiotic sources, like plants.