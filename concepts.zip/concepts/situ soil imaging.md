---
tags:
  - concept/definition
---
**In situ soil imaging** is a soil biota observation technique developped in [[Belaud2024_situsoil]].

It can capture photos regularly that can be timelapsed giving videos of what is happening in a layer of soil.
There are ongoing programs to treat such images with AI to perform larger scale species identification.

![[Belaud2024_situsoil_photo.png]]
![[Belaud2024_situsoil_example_image.png]]