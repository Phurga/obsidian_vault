---
tags:
  - concept/definition
aliases:
  - PCR
  - primer
  - primers
---
I think **polymerase chain reaction (PCR)** is the process of duplicating DNA regions ([[marker]]s) using by using specific **primers**.