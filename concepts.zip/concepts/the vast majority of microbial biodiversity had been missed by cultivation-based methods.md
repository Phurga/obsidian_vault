---
tags:
  - concept/idea
---
[[Hugenholtz1998_ImpactCultureIndependent]]
Text from wikipedia https://en.wikipedia.org/wiki/Metagenomics