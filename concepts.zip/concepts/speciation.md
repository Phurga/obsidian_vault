---
tags:
  - concept/definition
aliases:
---
**Speciation** occurs when organisms belonging to one [[taxonomy]] evolve to become too different to remain [[taxonomy|classified]] as the same specie. 