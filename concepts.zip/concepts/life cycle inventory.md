---
tags:
  - concept/definition
aliases:
  - elementary flows
  - LCI
---
In [[life cycle assessment]], the **life cycle inventory (LCI)** is on of the main stages of a study.

It consists in listing the **elementary flows** linked with the system model.

[[activity data]]
#todo/draft 