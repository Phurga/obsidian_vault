---
tags:
  - concept/definition
---
**GLOBI** is a database for [[symbiosis]].

https://www.globalbioticinteractions.org/

 #data 
 Related: [[Soil Food Web Ontology]]