---
tags:
  - concept/definition
aliases:
---
Regulating services are [[ecosystem service]] that regulate the ecosystem's biotope.
They include:
- water filtration
- climate regulation
- biological regulation (pest control)
- air filtration
- flood control
- erosion resistance