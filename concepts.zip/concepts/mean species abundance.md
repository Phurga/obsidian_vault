---
aliases:
  - MSA
  - species abundance
tags:
  - concept/definition
---
**Mean species abundance** is a metric used to assess the relative change of ([[native species|native]]) [[species abudance|species population]] under a given pressure.