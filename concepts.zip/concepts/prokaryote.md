---
tags:
  - concept/definition
aliases:
---
**Prokaryotes** are single cell organisms without a nucleus.
They inclue all [[bacteria]] and [[archae]].
They are opposed to [[eukaryote]].