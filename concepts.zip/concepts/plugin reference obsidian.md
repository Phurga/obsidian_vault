---
tags:
  - concept/idea
---
Switch on off (via command or via button) to transform links for source items (tagged as \#source) into a number with associated pandoc reference list on the side.