---
tags:
  - concept/definition
  - data
---
**splotOpen** is a database of plants records.

Defined in [[Sabatini2021_sPlotOpenenvironmentally]].