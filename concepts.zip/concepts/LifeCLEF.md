---
tags:
  - concept/definition
---
**LifeCLEF** is a contest and benchmark for [[species distribution model|SDM]]s.

https://www.imageclef.org/LifeCLEF2025