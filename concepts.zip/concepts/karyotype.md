---
tags:
  - concept/definition
---
The **karyotype** of an [[organism]] is the set of its chromosomes (package of [[DNA]]).

There is not a single karyotype similarity threshold allowing to define a species boundaries, as this similarity level depends on [[taxonomy|taxa]].