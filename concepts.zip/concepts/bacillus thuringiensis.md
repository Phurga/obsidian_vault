---
tags:
  - concept/definition
aliases:
---
**Bacillus thuringiensis** is a [[bacteria]], used as an insecticide, an example of [[biocontrol]]. [[FAO2020_Stateknowledge]]