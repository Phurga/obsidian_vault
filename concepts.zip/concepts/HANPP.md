---
tags:
  - concept/definition
aliases:
---
**Human appropriated net primary production** is a measure of the [[net primary production]] produced by [[ecosystem|ecosystems]] that is captured for human use. It is used as a measure of ecosystem [[functional integrity]] in the [[planetary boundaries]] framework.