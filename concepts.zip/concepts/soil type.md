---
tags:
  - concept/definition
  - todo/draft
aliases:
---
https://en.wikipedia.org/wiki/Soil_type

[[Référentiel Pédologique Français]]

[[pedology]]