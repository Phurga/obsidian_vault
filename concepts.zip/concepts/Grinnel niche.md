---
tags:
  - concept/definition
---
The **Grinnel niche**, named after [[Grinnell, Joseph]] is the match of an organism with abiotic factors ([[Si-Moussi2020_Contributiondata]]).

See [[Elton niche]].