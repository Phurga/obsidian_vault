---
tags:
  - concept/definition
aliases:
  - EF method
---
The **EF method** or the **PEF method**, is a LCA method to use for EU compliant LCAs. It provides multiple midpoints indicators as well as a normalization weighting procedure leading to a single score.

It is published by the [[EU JRC]].
Latest definition: [[Zampori2019_Suggestionsupdating]]