---
tags:
  - concept/definition
aliases:
  - CPCS
  - RPF
  - French Pedological Reference System
---
The **French Pedological Reference System (Référentiel pédologique Français** is a classfication of [[soil type]]s in France.

Published in [[Baize2009_Referentielpedologique]] by the [[Association Francaise pour l'étude des sols|AFES]].

This system replaces the **CPCS** (Commission de Pédologie et de Cartographie des Sols).
see [link](les-sols-dominants-de-france-metropolitaine_hautedef.pdf)
