---
tags:
  - concept/definition
aliases:
  - sfwo
---
The **Soil Food Web Ontology (SFWO)** is a wide database of [[food web|trophic relationships]] between soil organisms. It can be combined with the multi-trophic classification from [[Calderon-Sanou2022_betterunderstanding]].

Published in [[LeGuillarme2023_SoilFood]]
#data 