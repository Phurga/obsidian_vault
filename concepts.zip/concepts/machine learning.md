---
tags:
  - concept/definition
aliases:
  - deep learning
---
**Machine learning** is a branch of artificial intelligence involving statistical algorithms trained on large datasets, performing complex tasks without explicit instructions.

**Deep learning** is a subset of machine learning involving artificial neural networks.