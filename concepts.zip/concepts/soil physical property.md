---
tags:
  - concept/index
aliases:
  - soil physical properties
---
**Soil physical properties**
- [[soil texture]]
- [[soil aggregate]] and [[soil compaction]]
	- soil density
- [[soil sealing]] and water related properties