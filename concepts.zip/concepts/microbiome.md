---
tags:
  - concept/definition
---
The **microbiome** is the community of microbes and their associated molecules in an environment.

Source: https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/microbiome