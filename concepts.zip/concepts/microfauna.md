---
tags:
  - concept/definition
aliases:
---
In [[soil biodiversity|soil biodiversity]], the soil **microfauna** consists of:
- [[nematode]]
- [[protozoae]]