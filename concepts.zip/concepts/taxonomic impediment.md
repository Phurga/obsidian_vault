---
tags:
  - concept/definition
aliases:
  - taxonomic deficit
---
**Taxonomic impediment** refers to the fact that scientists can estimate there is a proportion of existing [[taxonomy]] that were not observed nor defined.

[[convention on biological diversity]]
https://www.cbd.int/gti/problem.shtml