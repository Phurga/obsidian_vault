---
tags:
  - concept/definition
  - data
---
**BOLD systems** is a database (actually a database compiling several databases) for [[DNA metabarcoding|DNA barcode]] characterized from [[environmental DNA]] and associated metadata (species, location, marker etc).

See [[BOLDSystems2025_Homepage]]