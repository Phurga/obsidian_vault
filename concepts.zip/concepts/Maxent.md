---
tags:
  - concept/definition
---
**Maxent** is a very important [[species distribution model|SDM]].

https://biodiversityinformatics.amnh.org/open_source/maxent