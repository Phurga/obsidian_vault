---
tags:
  - concept/definition
aliases:
---
Examples:

| Service                                                                    | Taxon    | Species                   | Notes       |
| -------------------------------------------------------------------------- | -------- | -------------------------- | ----------- |
| Plant growth                                                               | bacteria | [[Azospirillum]]          | large scale |
| [[substition of mineral fertilizer]] using [[biological nitrogen fixation]]) | bacteria | [[rhizobacteria]] strains | large scale |
