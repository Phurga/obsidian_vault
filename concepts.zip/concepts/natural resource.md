---
tags:
  - concept/definition
aliases:
  - natural resources
---
