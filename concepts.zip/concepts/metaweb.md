---
tags:
  - concept/definition
---
A **metaweb** is a regional network of biotic interaction, surpassing local [[food web]]s ([[Saravia2022_Ecologicalnetwork]]).

[[Saravia2022_Ecologicalnetwork]]
> We conceive of the metaweb as the source of food web structural diversity, from which local food web structure is drawn, and upon which local processes can act.