---
tags:
  - concept/definition
---
[[land use|land cover]] map for France with extended land classification
https://www.mdpi.com/2072-4292/9/1/95
![[CES OSO  THEIA_land_classes.png]]

made by the [[CESBIO]]