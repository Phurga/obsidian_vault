---
tags:
  - concept/definition
aliases:
---
**Tardigrades** are notable soil [[microfauna]] members. They are very close to arthoropods but are not because of how their body articulates.

A cute arthropod ([[Hedde2025_Diversityroles]]).
![[Hedde2025_SoilFauna_tardigrade.png|400]]
