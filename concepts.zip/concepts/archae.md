---
tags:
  - concept/definition
aliases: []
---
**Archae** are single cell [[microorganism]] that are very close to [[bacteria]] but have some differences I could not explain so I do not care. Let's consider all single cell microorganisms as bacteria.

Archae are important in the process of [[biological nitrogen fixation|biological nitrogen fixing]], since they can convert ammonia produced by [[rhizobacteria|N2 fixing bacteria]] into nitrates, more interesting for plants.

References:
[[FAO2020_Stateknowledge]]