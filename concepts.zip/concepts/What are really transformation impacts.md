---
tags:
  - concept/idea
aliases:
---
#todo/question if [[land use|land occupation]] bears all the impact what remains for the [[habitat transformation|land transformation]] impact, beside regeneration ?