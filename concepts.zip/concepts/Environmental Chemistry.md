---
tags:
  - concept/definition
---
Common keyword in automatic metadata related to [[life cycle assessment]] at the a more fundamental level.

Definition: "scientific study of the chemical and biochemical phenomena that occur in natural places" (wikipedia)