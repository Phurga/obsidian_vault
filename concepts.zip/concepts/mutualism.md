---
tags:
  - concept/definition
aliases:
  - mutualist
---
