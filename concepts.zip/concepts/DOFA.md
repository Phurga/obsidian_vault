---
tags:
  - concept/definition
---
**DOFA** is a [[Earth observation foundation model]] published in [[Xiong2024_NeuralPlasticityInspired]]. It was mentionned to be used for [[species distribution model#Deep SDM]] in the [[Deep SDM conference]].