---
tags:
  - concept/definition
aliases:
---
[[agricultural systems]]