---
tags:
  - concept/definition
  - todo/draft
aliases:
---
Alternative to [[equivalent connected area|ECA]] approach for [[habitat fragmentation|fragmentation]]) (https://doi.org/10.1038/35008063, https://doi.org/10.1073/pnas.1311491110).
#todo 