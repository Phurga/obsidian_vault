---
tags:
  - concept/definition
aliases:
---
An **epigeic** [[taxonomy]] lives on the surface of the [[soil]].

See [[earthworm]].