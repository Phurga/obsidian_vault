---
tags:
  - concept/idea
---
compare [[Burton2022_Landuse]] (showing important negative effects of land use intensification on soils species abundance) and [[Labouyrie2023_Patternssoil]] (showing positive effect of land use intensification on soils species richness).