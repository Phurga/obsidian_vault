---
tags:
  - concept/definition
---
There are 3 main publishers for the scientific literature:

[[Elsevier]]
[[Springer Nature]]
[[Wiley]]