---
tags:
  - concept/definition
aliases:
---
[[FAO2020_Stateknowledge]]