---
tags:
  - concept/index
---
- [[soil ph]]
- [[soil organic matter]]
- [[soil type]] (soil mineral composition)