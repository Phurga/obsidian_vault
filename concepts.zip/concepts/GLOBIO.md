---
tags:
  - concept/definition
aliases:
  - GLOBIO 4
---
**GLOBIO** is a model developped in [[PBL2016_GLOBIOMODEL]].
It uses [[mean species abundance]] as a metric for impacts on [[biodiversity]] ([[LCIA method for land use impacts on ecosystem quality]])

[[Schipper2020_Projectingterrestrial]]