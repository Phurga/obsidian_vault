---
aliases:
  - displacement
  - extirpation
tags:
  - concept/definition
  - todo/draft
---
When [[taxonomy]] are no longer in an [[biotope|habitat]], it can be because they have been eliminated or because they have been displaced: they have **migrated**. 