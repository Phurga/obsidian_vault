---
tags:
  - concept/idea
aliases:
---
Main thesis of [[Cameron2019_Globalmismatches]]: there is a not a straight correlation between above and below ground species richness. Temperate forest biomes are yellow (more above, less below), boreal/tundra are blue (less above, more below). Tropical regions have high above and below ground.
![[Cameron2019_Globalmismatches_map.jpg|400]]

