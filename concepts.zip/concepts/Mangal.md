---
tags:
  - concept/definition
---
**MANGAL** is a database for [[symbiosis]], eg used in [[species distribution model|SDM]].

https://mangal.io/

#data 