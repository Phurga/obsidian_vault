---
tags:
  - concept/definition
---
Based on discussions with [[Helias, Arnaud]]

Used to be lower than 1 for 1 and now being simplied to 1:1 relation.

PAF: potentially affected fraction of species
PDF: potentially disappeared fraction of species ([[relative species loss]])