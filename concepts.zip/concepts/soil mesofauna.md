---
tags:
  - concept/definition
aliases:
  - mesofauna
---
In [[soil biodiversity|soil biodiversity]], the soil **mesofauna** consists mainly of micro-[[soil arthropod]], which are mostly [[litter transformer]].