---
tags:
  - concept/definition
---
The **Swiss Agricultural Life Cycle Assessment (SALCA)** method was developped by [[Agroscope]] for performing LCA in the Swiss context.
There are some custom methods specific to the Swiss context:
- [[SALCA-BD]]
- [[SALCA-SQ]]
- and others
