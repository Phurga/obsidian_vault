---
tags:
  - concept/idea
---
soil as identity, terroir [[Cousin2025_Preserverqualite]]

our representation of nature and biodiversity is facing moral dilemnas (richness, invasive species, changes in ecoystem identity). In that case, index of nature would be closer to [[naturalness]] than other indicators ([[Vellend2017_BiodiversityConservation]])

ecosystem identity ?