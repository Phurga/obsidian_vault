---
tags:
  - concept/definition
  - todo/draft
aliases:
---
The **evolutionary distinctiveness score** is an method used to estimated how species are different based on their oldest parents #todo/notsure 