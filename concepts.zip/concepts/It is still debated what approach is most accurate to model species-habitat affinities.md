---
tags:
  - concept/definition
aliases:
---
[[Pereira2014_CountrysideSpecies]]