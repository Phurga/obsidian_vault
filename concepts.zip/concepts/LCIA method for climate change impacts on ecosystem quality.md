---
tags:
  - concept/definition
---
Main reference: [[Urban2015_Acceleratingextinction]] to link [[climate change]] impacts (midpoint) to [[ecosystem quality|ecosystem quality]] [[endpoint]] (PDF). Covers [[animal]] and [[plants]] only (not [[microorganism]])