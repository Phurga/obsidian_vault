---
tags:
  - concept/definition
aliases:
---
**Tetrapods** are animals with four legs. They include [[mammals]], [[birds]], [[reptiles]], [[amphibious]].
When combined with [[fish]] they basically make up the whole [[soil vertebrate|vertebrates]] phylum.